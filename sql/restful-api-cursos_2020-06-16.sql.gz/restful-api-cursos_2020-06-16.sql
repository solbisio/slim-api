# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.6.46)
# Database: restful-api-cursos
# Generation Time: 2020-06-16 20:59:35 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table assuntos
# ------------------------------------------------------------

DROP TABLE IF EXISTS `assuntos`;

CREATE TABLE `assuntos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `assuntos` WRITE;
/*!40000 ALTER TABLE `assuntos` DISABLE KEYS */;

INSERT INTO `assuntos` (`id`, `name`, `parent_id`)
VALUES
	(37,'teste assunto 1',0),
	(38,'teste assunto 2!!',0),
	(39,'teste assunto tipo 1.1!',37),
	(40,'teste assunto tipo 1.2!',37),
	(41,'teste assunto 1.2.1!!!!!!!! ?!',40),
	(42,'teste assunto 2.1!!',38),
	(43,'teste assunto 2.1.1!!',42),
	(44,'teste assunto 2.1.2!!!',42),
	(45,'teste assunto 2.1.3!',42),
	(46,'teste assunto 2.1.4!!!!!',42),
	(47,'teste assunto 2.2!',38);

/*!40000 ALTER TABLE `assuntos` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table banca
# ------------------------------------------------------------

DROP TABLE IF EXISTS `banca`;

CREATE TABLE `banca` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `banca` WRITE;
/*!40000 ALTER TABLE `banca` DISABLE KEYS */;

INSERT INTO `banca` (`id`, `name`)
VALUES
	(36,'teste banca 1'),
	(37,'teste banca 2'),
	(38,'teste banca 3');

/*!40000 ALTER TABLE `banca` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table orgao
# ------------------------------------------------------------

DROP TABLE IF EXISTS `orgao`;

CREATE TABLE `orgao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `orgao` WRITE;
/*!40000 ALTER TABLE `orgao` DISABLE KEYS */;

INSERT INTO `orgao` (`id`, `name`)
VALUES
	(3,'teste orgao 1'),
	(4,'teste orgao 2'),
	(5,'teste orgao 3');

/*!40000 ALTER TABLE `orgao` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table programa
# ------------------------------------------------------------

DROP TABLE IF EXISTS `programa`;

CREATE TABLE `programa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `banca_id` int(11) DEFAULT NULL,
  `orgao_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `programa` WRITE;
/*!40000 ALTER TABLE `programa` DISABLE KEYS */;

INSERT INTO `programa` (`id`, `name`, `banca_id`, `orgao_id`)
VALUES
	(1,'Teste Programa 1!!',36,3);

/*!40000 ALTER TABLE `programa` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table questao
# ------------------------------------------------------------

DROP TABLE IF EXISTS `questao`;

CREATE TABLE `questao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `assunto_id` int(11) NOT NULL,
  `orgao_id` int(11) NOT NULL,
  `banca_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `questao` WRITE;
/*!40000 ALTER TABLE `questao` DISABLE KEYS */;

INSERT INTO `questao` (`id`, `name`, `assunto_id`, `orgao_id`, `banca_id`)
VALUES
	(1,'teste',37,3,37),
	(2,'teste 2',37,3,36),
	(3,'teste 3',38,3,36),
	(4,'teste 4',38,3,36),
	(5,'teste 5',37,4,37),
	(6,'questão 6',37,4,38),
	(7,'questão 7!',37,3,36);

/*!40000 ALTER TABLE `questao` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
